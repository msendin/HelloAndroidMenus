package com.example.helloandroidmenus4;

import android.os.Bundle;
import android.app.Activity;

import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnLongClickListener;
import android.view.ActionMode;
import android.view.ActionMode.Callback;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.ActionBar;

//import android.app.ActionBar;

import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity implements OnLongClickListener, ActionMode.Callback {

	private TextView tv;

	private ActionMode mActionMode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);


		setContentView(R.layout.activity_main);
		tv = (TextView) findViewById(R.id.textview1);
		//registerForContextMenu(tv);
		//if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {

		//}



		//getWindow(). getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);



		tv.setOnLongClickListener(this);
			// Called when the user long-clicks on someView
	}

		public boolean onLongClick(View view) {
				if (mActionMode != null) {
					return false;
				}

				// Start the CAB using the ActionMode.Callback defined above
				mActionMode = this.startActionMode(this);
				view.setSelected(true);
				return true;
			}



			// Called when the action mode is created; startActionMode() was called
			@Override
			public boolean onCreateActionMode(ActionMode mode, Menu menu) {
				// Inflate a menu resource providing context menu items
				MenuInflater inflater = mode.getMenuInflater();
				inflater.inflate(R.menu.context_menu, menu);
				return true;
			}

			// Called each time the action mode is shown. Always called after
			// onCreateActionMode,
			// but may be called multiple times if the mode is invalidated.
			@Override
			public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
				return false; // Return false if nothing is done
			}

			// Called when the user selects a contextual menu item
			@Override
			public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
				switch (item.getItemId()) {
					case R.id.menu_actionM_op1:
						//tv.setText(tv.getText().toString().toUpperCase());
						getWindow(). getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
						mode.finish(); // Action picked, so close the CAB
						return true;
					case R.id.menu_actionM_op2:
						//tv.setText(tv.getText().toString() + tv.getText().toString());
						ActionBar actionBar = getSupportActionBar();
						actionBar.setTitle("New Menus");
						actionBar.setSubtitle("Action Bar confg.");
						mode.finish(); // Action picked, so close the CAB
						return true;
					default:
						return false;
				}
			}

			// Called when the user exits the action mode
			@Override
			public void onDestroyActionMode(ActionMode mode) {
				mActionMode = null;
			}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);

		menu.findItem(R.id.menu_opSearch).getActionView();

		return true;
	}
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
		String s;
		View v;
		if (item.getItemId() == R.id.menu_opSearch) {
			v = item.getActionView();
			Toast.makeText(this, "Collapsible Search Button" + " pulsado!", Toast.LENGTH_SHORT).show();
		}
		else {
			s = "Opcion Menu pulsada: " + item.getTitle().toString() + ". Orden: " + item.getOrder();
			tv.setText(s);
		}

        /*switch (item.getItemId()) {
        case R.id.menu_op1:  
        	tv.setText(s);
            return true;
        case R.id.menu_op2:
        	tv.setText("Opcion Menu 2 pulsada!");;
            return true;
        case R.id.menu_op3:
        	tv.setText("Opcion Menu 3 pulsada!");;
            return true;
        /*case R.id.SubMnuOpc1:
        	lblMensaje.setText("Opcion 3.1 pulsada!");;
            return true;
        case R.id.SubMnuOpc2:
        	lblMensaje.setText("Opcion 3.2 pulsada!");;
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }*/
		return true;
    }

	@Override
    public void onCreateContextMenu(ContextMenu menu, View v, 
    		                        ContextMenuInfo menuInfo) 
    {
		super.onCreateContextMenu(menu, v, menuInfo);		
		MenuInflater inflater = getMenuInflater();		
	    inflater.inflate(R.menu.menu_ctx_etiqueta, menu);
		
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
    	
    	
		//AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
    	
		switch (item.getItemId()) {
			case R.id.menu_cont_op1:
				Toast.makeText(this, "Etiqueta: Opcion Contextual " + item.getOrder() + " pulsada!", Toast.LENGTH_SHORT).show();
				return true;
			case R.id.menu_cont_op2:
				Toast.makeText(this, "Etiqueta: Opcion Contextual " + item.getOrder() + "  pulsada!", Toast.LENGTH_SHORT).show();
				return true;
			default:
				return super.onContextItemSelected(item);
		}
    }


}
